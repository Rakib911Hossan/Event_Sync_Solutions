package com.Corporate.Event_Sync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventSyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
